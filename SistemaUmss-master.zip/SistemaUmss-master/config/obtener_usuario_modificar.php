<?php 
require_once 'conexion.php';

function obtener_nombre($ci){
    $query = "SELECT nombre FROM usuario WHERE ci = '$ci' ;";
    $result = $conexion->query($query);
    
    $row = $result->fetch_assoc();
    $nombreUsuario = $row['nombre'];
    return $nombreUsuario;
}

function obtener_apellido($ci){
    $query = "SELECT apellidos FROM usuario WHERE ci= '$ci'";
$result = $conexion->query($query);

$row = $result->fetch_assoc();
$apellidoUsuario = $row['apellidos'];
return $apellidoUsuario;
}

function obtener_correo($ci){
    $query = "SELECT correo FROM usuario WHERE ci = '$ci'";
    $result = $conexion->query($query);
    
    $row = $result->fetch_assoc();
    $correoUsuario = $row['correo'];
    return $correoUsuario;
}
?>