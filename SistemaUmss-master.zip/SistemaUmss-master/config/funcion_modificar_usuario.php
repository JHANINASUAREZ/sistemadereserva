<?php

// Include database connection
include('conexion.php');
// Check if the form has been submitted
if (isset($_POST['nombre']) && isset($_POST['apellido']) && isset($_POST['facultad'])) {
    // Get the form data
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $facultad = $_POST['facultad'];

    // Construct the SQL query to update the user information
    $sql = "UPDATE usuario SET nombre='.'$nombre'.', apellidos='.'$apellido'.' WHERE ci='.'$ci'.';";

    // Execute the query
    if (mysqli_query($conexion, $sql)) {
        echo "<p>Usuario actualizado con éxito.</p>";
    } else {
        echo "<p>Error al actualizar el usuario: " . mysqli_error($conexion) . "</p>";
    }
}

?>
