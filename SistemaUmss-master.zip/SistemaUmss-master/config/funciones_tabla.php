<?php

function obtener_usuarios_tabla($conexion) {
    $sql = "SELECT nombre, correo, ci FROM usuario";
    $resultado = mysqli_query($conexion, $sql);

    if (mysqli_num_rows($resultado) > 0) {
        return $resultado;
    } else {
        return false;
    }
}

function generar_tabla_usuarios($resultado) {
    if ($resultado) {
        
        echo '<tbody>';

        while ($fila = mysqli_fetch_assoc($resultado)) {
            echo '<tr>';
            echo '<td>' . $fila['nombre'] . '</td>';
            echo '<td>' . $fila['correo'] . '</td>';
            echo '<td>' . $fila['ci'] . '</td>';
            echo '<td><a href="modificar_cuenta_usuario.php?ci=' . $fila['ci'] . '" class="btn btn-primary">Modificar</a></td>';
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
    } else {
        echo '<p>No hay usuarios registrados.</p>';
    }
}

function buscar_usuario_ci_correo(){

// Receive search parameters from AJAX request
$correoElectronico = $_POST['correoElectronico'];
$ci = $_POST['ci'];

// Connect to the database
// ... (Database connection code as in index.php) ...

// Construct the filtered SQL query
$sql = "SELECT * FROM usuario WHERE correo LIKE '%$correoElectronico%' OR ci LIKE '%$ci%'";

// Fetch filtered user data
$resultado = mysqli_query($conexion, $sql);

// Generate dynamic HTML table
if (mysqli_num_rows($resultado) > 0) {
    echo '<table class="table table-striped">';
    echo '<thead>';
    echo '<tr>';
    echo '<th>Nombre</th>';
    echo '<th>Correo</th>';
    echo '<th>CI</th>';
    echo '<th>Modificar</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';

    while ($fila = mysqli_fetch_assoc($resultado)) {
        echo '<tr>';
        echo '<td>' . $fila['nombre'] . '</td>';
        echo '<td>' . $fila['correo_electronico'] . '</td>';
        echo '<td>' . $fila['CI'] . '</td>';
        echo '<td><a href="modificar_cuenta_usuario.php?CI=' . $fila['CI'] . '" class="btn btn-primary">Modificar</a></td>';
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
} else {
    echo '<p>No se encontraron usuarios con los criterios de búsqueda.</p>';
}



}

?>
