<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registrar Usuario</title>
<link rel="stylesheet" type="text/css" href="../cssp/styles.css">
<script>
function enviarFormulario() {
    // Obtener el formulario
    var formulario = document.getElementById("formularioRegistro");

    // Enviar el formulario utilizando AJAX
    var xhr = new XMLHttpRequest();
    xhr.open(formulario.method, formulario.action, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Si la respuesta es exitosa, mostrar el mensaje y borrar los datos del formulario
            alert(xhr.responseText);
            formulario.reset();
        } else {
            // Si hay un error en la respuesta, mostrar un mensaje de error
            alert('Error al registrar usuario: ' + xhr.statusText);
        }
    };
    xhr.send(new URLSearchParams(new FormData(formulario)));
}
</script>
</head>
<body>


<div class="container">
    <h2>Registrar Usuario</h2>
    <!-- Agregar el identificador al formulario y llamar a la función JavaScript al hacer clic en el botón Registrar -->
    <form id="formularioRegistro" method="post" action="../../config/procesar_registro.php" onsubmit="event.preventDefault(); enviarFormulario();">
        <input type="text" name="nombre" placeholder="Nombres" required>
        <input type="text" name="apellido" placeholder="Apellidos" required>
        <input type="email" name="correo" placeholder="Correo electrónico" required>
        <input type="password" name="contrasena" placeholder="Contraseña" required>
        <input type="password" name="confirmar_contrasena" placeholder="Confirmar Contraseña" required>
        <input type="text" name="materias" placeholder="Materias" required> 
        <input type="text" name="carrera" placeholder="Carrera" required>
        <select name="rol" required>
            <option value="1">Administrador</option>
            <option value="2">Docente</option>
        </select>
        <button type="submit">Registrar</button>
        <button type="button" onclick="window.location.href='./HomeA.php'">Cancelar</button>
    </form>
</div>


</body>
</html>
<?php

